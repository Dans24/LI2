//Movimento

var map = {};
var mov = 1;

document.onkeydown = function(e){
  if(mov){
    e = e || window.event;
    map[e.keyCode] = 1;
    setTimeout(move,300);
  }
}

function move(){
  esquerda = map[37] || 0;
  direita = map[39] || 0;
  cima = map[38] || 0;
  baixo = map[40] || 0;
  if(esquerda || direita || cima || baixo){
    var x = 1 - esquerda + direita;
    var y = 1 - cima + baixo;
    var query = ".dir[data-x='" + x + "'][data-y='" + y + "']";
    var selector = document.querySelector(query);
    if(selector){
      mov = 0;
      location.href = selector.getAttribute('xlink:href');
    }
    map = {};
  }
}
