#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "cgi.h"
#include "estado.h"

/**
@file highscore.h
Definição de funções sobre os highscores
*/

/**
\brief Descodifica texto conficado para url
@param string Texto a descodificar
@return Texto descodificado
*/
char* urlDecode(char* string);

/**
\brief Os caracteres inseguros de html são convertidos em caracteres seguros
@param string Texto
@return Texto seguro
*/
char* HTMLentitles(char* string);

/**
\brief Trunca o Texto
@param str Texto a ser truncado e destino da truncação
@param tam tamanho máximo do texto
@return Texto truncado
*/
char* truncate(char* str, int tam);

/**
\brief Insere os valores superiores e o novo no anterior
@param f Ficheiro com os highscores
@param anterior Texto destino do highscore anterior e o novo highscore
@param nome Texto com o nome do utilizador
@param nova_pontuacao Pontuação do utilizador
@return Índice da posição do novo highscore
*/
int inserirHighscore(FILE* f, char* anterior, char* nome, int nova_pontuacao);

/**
\brief Insere os highscore no ficheiro f
@param f Ficheiro com os highscores
@param nome Texto com o nome do utilizador
@param nova_pontuacao Pontuação do utilizador
@return Índice da posição do novo highscore
*/
int atualizarHighscore(FILE* f, char* nome, int nova_pontuacao);

/**
\brief Guarda o novo highscore no ficheiro
@param nome Nome do utilizador
@param nova_pontuacao Pontuação do utilizador
@returns Índice da sua posição
*/
int novoHighscore(char* nome, int nova_pontuacao);

/**
\brief Torna o nome válido e seguro para apresentar na página
@param nome Nome do utilizador
@return Texto do nome próprio para a página HTML
*/
char* nomeValido(char* nome);

/**
\brief Imprimes os highscores
@param i Índice do highscore
@param indice_novo_highscore Índice do novo highscore
@param nome Nome do utilizador a imprimir
@param pontuacao pontuacao do utilizador a imprimir
*/
void imprimeHighscore(int i, int indice_novo_highscore, char* nome, int pontuacao)

/**
\brief Imprimes os highscores
@param indice_novo_highscore Índice do novo highscore
*/
void imprimeHighscores(int indice_novo_highscore);

/**
\brief Obtem o estado codificado em texto do jogador
@param id Id do jogador
*/
char* obter_estado(int id);

/**
\brief O id do jogador
@return Retorna o número do jogador ou cria um novo
*/
int obter_id();

/**
\brief Imprime na página
@param indice_novo_highscore Índice do novo highscore
*/
void imprime(int indice_novo_highscore);

/**
\brief Atualiza os highscores e imprime a página
*/
int main();
