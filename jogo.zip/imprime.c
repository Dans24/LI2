#include "items.c"

#define ESCALA					50
#define OFFSET					50

#define SX                      770
#define SY                      100


void imprime_fundo() {
	int tamanho = TAM * ESCALA + 2 * ESCALA;
	FOTOGRAFIA(0,0,tamanho,tamanho,"bg.png");
 	//FOTOGRAFIA(650,0,tamanho,tamanho,"quadrado.png"); //zona para stats e items

}

void imprime_portas(int sala) {
	//Tamanho das imagens
	int tamanhoX = 74;
	int tamanhoY = 50;

	//Calculos para centrar as imagens nos respetivos sítios
	int inicio = ESCALA - tamanhoY;
	int meio = (TAM / 2 + 1) * ESCALA - (tamanhoX - ESCALA) / 2;
	int fim = (TAM + 1) * ESCALA;

	//Coloca as portas no sítio
	if(tem_sala(sala, sala - 1))
		FOTOGRAFIA(inicio, meio, tamanhoY, tamanhoX, "porta4.png");
	if(tem_sala(sala, sala + 1))
		FOTOGRAFIA(fim, meio, tamanhoY, tamanhoX, "porta2.png");
	if(tem_sala(sala, sala - 3))
		FOTOGRAFIA(meio, inicio, tamanhoX, tamanhoY, "porta1.png");
	if(tem_sala(sala, sala + 3))
		FOTOGRAFIA(meio, fim, tamanhoX, tamanhoY, "porta3.png");
}



void imprime_casa(int x, int y) {
	int i = 1 + random() % 8;         //nr tiles diferentes
	QUADRADO_BG(x, y, ESCALA, i);
}

void imprime_casas() {
	int x, y;
	for(y = 0; y < TAM; y++)
		for(x = 0; x < TAM; x++)
			imprime_casa(x, y);
}

void imprime_escadas(ESTADO e) {
	if(e.info.sala == e.escada.sala){
		int X, Y;
		X = e.escada.pos.x;
		Y = e.escada.pos.y;
		IMAGEM(X,Y,ESCALA,"tilestairsdown.png");
	}
}

void imprime_items(ESTADO e){
	int i, id;
	for(i = 0; i < (int) e.num[NITEM][SALA_ATUAL]; i++){
		id = ITM.pos.dir;
		if (id > 100)
		IMAGEM(ITM.pos.x + 5, ITM.pos.y + 5, ESCALA - 10, item_id((int) id));
		else
		IMAGEM(ITM.pos.x, ITM.pos.y, ESCALA, item_id((int) id));
	}
}

void imprime_jogador(ESTADO anterior, ESTADO e) {
	if(anterior.info.sala == e.info.sala && anterior.info.nivel == e.info.nivel) {
		PERSONAGEM_MOVIMENTO(anterior.infojog.pos, JOG.pos, "jogador", "rui2.png", 0.3f);
	} else {
		PERSONAGEM(JOG.pos, "jogador", "rui.png");
	}
}

void imprime_vida(int vida, POSICAO p, int espessura){
	int X = p.x * ESCALA + OFFSET;
	int Y = p.y * ESCALA + OFFSET;
	int n = 0;

	 //barras cheias
	while (vida > 50) {
		RETANGULO(X + 1, Y + n * espessura + 1, ESCALA, espessura, "black");
		RETANGULO(X, Y + n * espessura + 1, ESCALA, espessura - 1, "red");
		vida -= 50;
		n--;
	}

	//barra do topo
	RETANGULO(X + 1,Y + n * espessura + 2, vida, espessura - 1, "black");
	RETANGULO(X ,Y + n * espessura + 1, vida, espessura - 1, "red");
}

void imprime_inimigos(ESTADO anterior, ESTADO e) {
	char* img[] = {		"Esqueleto.png", "Esqueleto_com_armadura.png", "Esqueleto_elite.png",
						"Esqueleto_arqueiro.png", "Esqueleto_arqueiro_com_armadura.png",
	 					"Esqueleto_aprendiz.png", "Esqueleto_mago.png", "Esqueleto_mestre.png",
	 					"Hoplita.png", "Paladino.png"};
	int i;
	POSICAO pos_anterior;
	if(anterior.info.sala == e.info.sala &&
		 e.num[INIMIGO][SALA_ATUAL] == anterior.num[INIMIGO][SALA_ATUAL] &&
	 	 anterior.info.nivel == e.info.nivel){
		for(i = 0; i < (int) e.num[INIMIGO][SALA_ATUAL]; i++){
			pos_anterior = anterior.inimigo[(int) e.info.sala][i].pos;
			PERSONAGEM_MOVIMENTO(pos_anterior, INI.pos, "inimigo", img[(int) INI.tipo.tipo], 0.3f);
			imprime_vida(INI.vida, INI.pos, 5);
		}
	} else {
		for(i = 0; i < (int) e.num[INIMIGO][SALA_ATUAL]; i++){
			PERSONAGEM(INI.pos, "inimigo", img[(int) INI.tipo.tipo]);
			imprime_vida(INI.vida, INI.pos, 5);
		}
	}
}

void imprime_obstaculos(ESTADO e){
	char* img[] = {"barrel.png", "box1.png", "box2.png"};
	int i;
	for(i = 0; i < (int) e.num[OBSTACULO][SALA_ATUAL]; i++){
		PERSONAGEM(OBS.pos, "obstaculo", img[i % 3]);
	}
}

void imprime_objetos(ESTADO anterior, ESTADO e) {
	imprime_items(e);
	imprime_obstaculos(e);
	imprime_inimigos(anterior, e);
	imprime_jogador(anterior, e);
}



void imprime_mov_porta(int x, int y) {
	//Tamanho das imagens
	int tamanhoX = 74;
	int tamanhoY = 50;

	//Calculos para centrar as imagens nos respetivos sítios
	int inicio = ESCALA - tamanhoY;
	int meio = (TAM / 2 + 1) * ESCALA - (tamanhoX - ESCALA) / 2;
	int fim = (TAM + 1) * ESCALA;

	//Coloca as sombras no sítio
	if(x == -1)
		FOTOGRAFIA(inicio, meio, tamanhoY, tamanhoX, "green4.png");
	else if(x == TAM)
		FOTOGRAFIA(fim, meio, tamanhoY, tamanhoX, "green2.png");
	else if(y == -1)
		FOTOGRAFIA(meio, inicio, tamanhoX, tamanhoY, "green1.png");
	else if(y == TAM)
		FOTOGRAFIA(meio, fim, tamanhoX, tamanhoY, "green3.png");
}

void imprime_movimento(ESTADO e, int dx, int dy) {
    int x = JOG.pos.x + dx, y = JOG.pos.y + dy;
    int sala = e.info.sala + ir_porta(x, y);
    int sala_disponivel = tem_sala(e.info.sala, sala);
    char link[10] = "?";
    if(invalido(x, y, e))
        return;
    sprintf(link, "?0,%d,%d", x, y);
    ABRIR_DIRECAO(dx + 1, dy + 1, link);
    if(ir_porta(x, y) && sala_disponivel) //entrar em porta
        imprime_mov_porta(x, y);
    else if (tem_inimigo(e, x, y)) //atacar inimigo
    	QUADRADO(x, y, ESCALA, "rgba(200,0,0,0.2)");
    else if (tem_item(e, x, y)) //apanhar item
    	QUADRADO(x, y, ESCALA, "rgba(0,0,200,0.2)");
    else //movimento normal
    	QUADRADO(x, y, ESCALA, "rgba(0,200,0,0.1)");
    FECHAR_LINK;
}

void imprime_movimentos(ESTADO e) {
	int x, y;
	int alcance;
	if(JOG.equipados[0] > 80)
		alcance = 4;
	else
		alcance = 1;
	for(x = -alcance; x <= alcance; x++){
		for(y = -alcance; y <= alcance; y++){
			if(x || y){
				imprime_movimento(e, x, y);
			}
		}
	}
}

void imprime_butao_trocar() {
	ABRIR_LINK("?1,0,0");
	AGRUPAR;
	DESCRICAO("equipar");
	FOTOGRAFIA(SX + 130, SY + 210, 50, 50, "butao_equipar.png");
	FIM_AGRUPAR;
	FECHAR_LINK;
}

void imprime_butao_largar() {
	ABRIR_LINK("?2,0,0");
	AGRUPAR;
	DESCRICAO("largar");
	FOTOGRAFIA(SX + 180, SY + 215, 40, 40, "butao_largar.png");
	FIM_AGRUPAR;
	FECHAR_LINK;
}

void imprime_butao_danificado() {
	FOTOGRAFIA(SX + 130, SY + 210, 50, 50, "butao_equipar.png");
	AGRUPAR;
	DESCRICAO("escudo danificado");
	FOTOGRAFIA(SX + 135, SY + 215, 40, 40, "red_cross.png");
	FIM_AGRUPAR;
}

void imprime_usarinv(ESTADO e) {
	int inv = JOG.inventario;
	//trocar
	//escudo
	if (inv > 100 && inv <= 110) {
		if (!JOG.equipados[1] || (int) JOG.armadura == armadura_escudo(JOG.equipados[1])) {
			imprime_butao_trocar();
		//escudo danificado
		} else {
			imprime_butao_danificado();
		}
	}
	//outros
	else if (inv) {
		imprime_butao_trocar();
	}

	//largar
	if (inv) {
		imprime_butao_largar();
	}
}
void imprime_barra_vida(int vida, int armadura) {
	//barra de vida
	RETANGULO(SX + 40, SY - 8, vida, 30, "rgba(0,230,0,1)");
	RETANGULO(SX + 40, SY - 4, vida - 4, 22, "rgba(0,164,0,1)");
	RETANGULO(SX + 40, SY, vida - 8, 14, "rgba(0,135,0,1)");

	//armadura
	RETANGULO(SX + 40, SY - 8, armadura, 30, "rgba(80,80,80,0.6)");
	RETANGULO(SX + 40, SY - 4, armadura - 4, 22, "rgba(80,80,80,0.4)");
	RETANGULO(SX + 40, SY, armadura - 8, 14, "rgba(80,80,80,0.1)");

	//moldura barra de vida
	FOTOGRAFIA(SX - 80, SY - 23, 415, 60, "barradevida.png");
	if (armadura > 0) FOTOGRAFIA(SX - 80, SY - 23, 415, 60, "armor.png");
	if (vida <= 0) FOTOGRAFIA(SX - 80, SY - 23, 415, 60, "morto.png");
}

void imprime_jog_arma(int idarma) {
	AGRUPAR;
	DESCRICAO("Arma");
	FOTOGRAFIA(SX, SY + 100, 70, 70, "slot_arma.png");
	FIM_AGRUPAR;

	if (idarma) {
		int dano = dano_arma(idarma);
		char desc[MAX_BUFFER];
		sprintf(desc, "Dano: %d", dano);
		if(idarma < 80){
			strcat(desc, "   Alcance: 1");
		} else {
			strcat(desc, "   Alcance: 4");
		}
		AGRUPAR;
		DESCRICAO(desc);
		FOTOGRAFIA(SX + 10, SY + 110, 50, 50, item_id(idarma));
		FIM_AGRUPAR;
	}
}

void imprime_jog_escudo(int idescudo) {
	AGRUPAR;
	DESCRICAO("Escudo");
	FOTOGRAFIA(SX + 100, SY + 100, 70, 70, "slot_escudo.png");
	FIM_AGRUPAR;

	if (idescudo) {
		int armadura = armadura_escudo(idescudo);
		printf("<g>\n<title>%d armadura inicial</title>\n", armadura);
		FOTOGRAFIA(SX + 115, SY + 115, 40, 40, item_id(idescudo));
		FIM_AGRUPAR;
	}
}

void imprime_jog_consumiveis(int idcons) {
	AGRUPAR;
	DESCRICAO("Consumiveis");
	FOTOGRAFIA(SX + 220, SY + 100, 70, 70, "slot_consumiveis.png");
	FIM_AGRUPAR;


	if (idcons) {
		int cura = (idcons - 110) * 10;
		ABRIR_LINK("?3,0,0");
		printf("<g>\n<title>Curar %d de vida</title>\n", cura);
		FOTOGRAFIA(SX + 230, SY + 110, 50, 50, item_id(idcons));
		FIM_AGRUPAR;
		FECHAR_LINK;
	}
}

void imprime_jog_inventario(int idinv) {
	AGRUPAR;
	DESCRICAO("Inventario");
	FOTOGRAFIA(SX + 50, SY + 200, 70, 70, "slot_inventario.png");
	FIM_AGRUPAR;

	AGRUPAR;
	if (idinv > 110) {
		int cura = (idinv - 110) * 10;
		printf("<g>\n<title>Cura %d de vida</title>\n", cura);
		FOTOGRAFIA(SX + 60, SY + 210, 50, 50, item_id(idinv));
		}
	else if (idinv > 100) {
		int armadura = armadura_escudo(idinv);
		printf("<g>\n<title>%d armadura inicial</title>\n", armadura);
		FOTOGRAFIA(SX + 65, SY + 215, 40, 40, item_id(idinv));
	}
	else if (idinv) {
		int dano = dano_arma(idinv);
		printf("<g>\n<title>%d dano</title>\n", dano);
		FOTOGRAFIA(SX + 60, SY + 210, 50, 50, item_id(idinv));
	}
	FIM_AGRUPAR;
}


void imprime_stats(ESTADO e) {
	int armadura = (float) JOG.armadura * 2.1;
	int vida = (float) JOG.vida * 2.1;
	int idarma = JOG.equipados[0];
	int idescudo = JOG.equipados[1];
	int idcons = JOG.consumiveis;
	int idinv = JOG.inventario;

	imprime_barra_vida(vida, armadura);

	imprime_jog_arma(idarma);
	imprime_jog_escudo(idescudo);
	imprime_jog_consumiveis(idcons);
	imprime_jog_inventario(idinv);
	imprime_usarinv(e);

	//pontuacao
	char pont[3];
	sprintf(pont, "%d", e.info.pontuacao);
	TEXTO(SX + 52, 2, ESCALA, "black", pont);
	TEXTO(SX + 50, 0, ESCALA, "red", pont);

}

void imprime_ajudas(ESTADO e){
	int mapa[TAM][TAM];
	for(int i = 0; i < e.num[INIMIGO][SALA_ATUAL]; i++){
		obterAjuda(e, mapa, i, INI.tipo.alcance);
		for(int x = 0; x < TAM; x++){
			for(int y = 0; y < TAM; y++){
				int v = mapa[x][y];
				if(v == 0 && !tem_inimigo(e, x, y))
					QUADRADO(x, y, ESCALA, "rgba(255,255,0,0.1)");
			}
		}
	}
}


void imprime_butao_ajudas(ESTADO e) {
	ABRIR_LINK("?4,0,0");
	AGRUPAR;
	if (e.info.ajudas) {
		DESCRICAO("Esconder alcance dos inimigos");
		FOTOGRAFIA(SX + 30, SY + 300, 50, 50, "ajudas.png");
		imprime_ajudas(e);
	}
	else {
		DESCRICAO("Mostrar alcance dos inimigos");
		FOTOGRAFIA(SX + 30, SY + 300, 50, 50, "ajudasd.png");
	}
	FIM_AGRUPAR;
	FECHAR_LINK;
}

ESTADO ajudas(ESTADO e) {
	if (e.info.ajudas) e.info.ajudas = 0;
	else e.info.ajudas = 1;
    return e;
}

void imprime_mapa(ESTADO e) {
	int atual = SALA_ATUAL;
	int i, caso, n;
	char* img[] = {"sala_atual.png", "sala_visitada.png", "sala_nao_visitada.png"};
	for (i = 0; i < 9; i++) {
		if (i == atual) caso = 0;
		else if (e.salas[i].visited == 1) caso = 1;
		else caso = 2;
		if (i > 5) n = 2; else if (i > 2) n = 1; else n = 0;
		FOTOGRAFIA(SX + 30 + (i % 3) * 53, SY + 360 + n * 45, 60, 50, img[caso]);
		if (i == e.escada.sala && e.salas[(int) e.escada.sala].visited)
			FOTOGRAFIA(SX + 41 + (i % 3) * 53, SY + 372 + n * 45, 40, 30, "prox_piso.png");
	}
}

void imprime(ESTADO anterior, ESTADO e){
	srandom(e.info.sala + e.info.nivel * 10);

	imprime_fundo();
	imprime_portas(e.info.sala);
	imprime_casas();

	imprime_butao_ajudas(e);

	imprime_escadas(e);
	imprime_objetos(anterior, e);
	imprime_stats(e);
	imprime_mapa(e);

	//jogador morto
	if (JOG.vida <= 0) {
		TEXTO(750, 150, ESCALA, "red", "Morreste.");
	} else {
		imprime_movimentos(e);
	}
}
