#ifndef ___CGI_H___
#define ___CGI_H___

/**
@file cgi.h
Macros úteis para gerar CGIs
*/

#include <stdio.h>


/**
\brief Tamanho máximo de um array
*/
#define MAX_BUFFER 																															10240
/**
\brief Caminho para as imagens
*/
#define IMAGE_PATH																															"http://localhost/images/"

/**
\brief Macro para começar o html
*/
#define COMECAR_HTML																														printf("Content-Type: text/html\n\n<!DOCTYPE>\n" \
																																									"<title>Cave do Barbas</title>\n" \
																																									"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />\n" \
																																									"<body style='background-color: #cccccc'>\n")

/**
\brief Macro para abrir um svg
@param tamx O comprimento do svg
@param tamy A altura do svg
*/
#define ABRIR_SVG(tamx, tamy)																										printf("<svg width=%d height=%d style='position: fixed;top: 50%%;left: 50%%;" \
																																									"transform: translate(-50%%, -50%%)'>\n", tamx, tamy)

/**
\brief Macro para fechar um svg
*/
#define FECHAR_SVG																															printf("</svg>\n")

/**
\brief Macro para criar uma imagem
@param X A coordenada X do canto superior esquerdo
@param Y A coordenada Y do canto superior esquerdo
@param ESCALAX A escala da imagem
@param FICHEIRO O caminho para o link do ficheiro
*/
#define IMAGEM(X, Y, ESCALAX, FICHEIRO)																					printf("<image x=%d y=%d width=%d height=%d xlink:href=%s%s />\n", \
																																									ESCALA * X + OFFSET, ESCALA* Y + OFFSET, ESCALAX, ESCALAX, IMAGE_PATH, FICHEIRO)

/**
\brief Macro que imprime a imagem de um personagem
@param POS Posição da personagem no estado atual
@param GRUPO Nome do grupo de que a personagem pertence
@param FICHEIRO O caminho para o link do ficheiro
*/
#define IMAGEM_PERSONAGEM(POS, GRUPO, FICHEIRO)																	if(POS.dir) \
																																									printf("<image x=%d y=%d width=%d height=%d class=%s xlink:href=%s%s fill='freeze'>\n",\
																																									ESCALA * POS.x + OFFSET, ESCALA * POS.y + OFFSET,\
																																									ESCALA, ESCALA, GRUPO, IMAGE_PATH, FICHEIRO); \
																																								else \
																																									printf("<image x=%d y=%d width=%d height=%d transform=scale(-1,1) " \
																																									"class=%s xlink:href=%s%s fill='freeze'>\n",\
																																									- ESCALA * POS.x - 2 * OFFSET, ESCALA * POS.y + OFFSET,\
																																									ESCALA, ESCALA, GRUPO, IMAGE_PATH, FICHEIRO);

/**
\brief Macro que imprime um personagem
@param POS Posição da personagem no estado atual
@param GRUPO Nome do grupo de que a personagem pertence
@param FICHEIRO O caminho para o link do ficheiro
*/
#define PERSONAGEM(POS, GRUPO, FICHEIRO)																				IMAGEM_PERSONAGEM(POS, GRUPO, FICHEIRO); \
																																								printf("</image>");

/**
\brief Macro que imprime o movimento de uma personagem
@param POS_ANTERIOR Posição da personagem no estado anterior
@param POS Posição da personagem no estado atual
@param GRUPO Nome do grupo que a personagem pertence
@param FICHEIRO O caminho para o link do ficheiro
@param DUR Duração da animação em segundos
*/
#define PERSONAGEM_MOVIMENTO(POS_ANTERIOR, POS, GRUPO, FICHEIRO, DUR) 					if(POS.dir){ \
																																									IMAGEM_PERSONAGEM(POS, GRUPO, FICHEIRO); \
																																									MOVIMENTO(POS_ANTERIOR, POS, DUR) \
																																								} else { \
																																									IMAGEM_PERSONAGEM(POS, GRUPO, FICHEIRO); \
																																									MOVIMENTO(POS_ANTERIOR, POS, DUR) \
																																								}

/**
\brief MACRO que imprime movimentações
@param POS_ANTERIOR Posição da personagem no estado anterior
@param POS Posição da personagem no estado atual
@param DUR Duração da animação em segundos
*/
#define MOVIMENTO(POS_ANTERIOR, POS, DUR)																				if(POS.dir){ \
																																									printf("<animate attributeType=XML attributeName=x from=%d to=%d dur=%f />\n", ESCALA * POS_ANTERIOR.x + OFFSET, ESCALA * POS.x + OFFSET, DUR); \
																																								} else { \
																																									printf("<animate attributeType=XML attributeName=x from=%d to=%d dur=%f />\n", - ESCALA * POS_ANTERIOR.x - 2 * OFFSET, - ESCALA * POS.x - 2 * OFFSET, DUR); \
																																								} \
																																								printf("<animate attributeType=XML attributeName=y from=%d to=%d dur=%f />\n", ESCALA * POS_ANTERIOR.y + OFFSET, ESCALA * POS.y + OFFSET, DUR); \
																																								printf("</image>\n");

/**
\brief Macro para criar uma imagem com posição absoluta
@param X A coordenada X do canto superior esquerdo
@param Y A coordenada Y do canto superior esquerdo
@param ESCALAX A escala da imagem no eixo do x
@param ESCALAY A escala da imagem no eixo do y
@param FICHEIRO O caminho para o link do ficheiro
*/
#define FOTOGRAFIA(X, Y, ESCALAX, ESCALAY, FICHEIRO)														printf("<image x=%d y=%d width=%d height=%d xlink:href=%s%s />\n", \
																																								X, Y, ESCALAX, ESCALAY, IMAGE_PATH, FICHEIRO)

/**
\	brief Adiciona uma descrição ao objeto
@param TITLE A descrição do objeto
*/
#define DESCRICAO(TITLE)																												printf("<title>%s</title>\n", TITLE)

/**
\brief Inicia um grupo de objetos
*/
#define AGRUPAR																																	printf("<g>\n")

/**
\brief Inicia um grupo de objetos
*/
#define FIM_AGRUPAR																															printf("</g>\n")

/**
\brief Macro para criar um quadrado
@param X A coordenada X do canto superior esquerdo
@param Y A coordenada Y do canto superior esquerdo
@param ESCALA A escala do quadrado
@param INDICE O índice da imagem de preenchimento do quadrado
*/
#define QUADRADO_BG(X, Y, ESCALA, INDICE)																				printf("<image x=%d y=%d width=%d height=%d xlink:href=%stile%d.png />\n", \
																																								ESCALA * X + OFFSET, ESCALA* Y + OFFSET, ESCALA, ESCALA, IMAGE_PATH, INDICE)

/**
\brief Macro para criar um quadrado
@param X A coordenada X do canto superior esquerdo
@param Y A coordenada Y do canto superior esquerdo
@param ESCALA A escala do quadrado
@param COR A cor de preenchimento do quadrado
*/
#define QUADRADO(X, Y, ESCALA, COR)																							printf("<rect x=%d y=%d width=%d height=%d fill=%s />\n", \
																																								ESCALA * X + OFFSET, ESCALA* Y + OFFSET, ESCALA, ESCALA, COR)

/**
\brief Macro para criar um retangulo

*/
#define RETANGULO(X, Y, LARGURA, ALTURA, COR)																		printf("<rect x=%d y=%d width=%d height=%d fill=%s />\n", \
																																								X , Y , LARGURA, ALTURA, COR)

/**
\brief Macro para criar texto
*/
#define TEXTO(X, Y, ESCALA, COR, TEXT)																					printf(" <text x=\"%d\" y=\"%d\" font-family=\"Arial\" font-size=\"%d\" fill=\"%s\"> %s </text>\n", \
																																								X, Y + ESCALA , ESCALA, COR, TEXT);

/**
\brief Macro para abrir um link
@param link O caminho para o link
*/
#define ABRIR_LINK(link)																												printf("<a xlink:href=%s>\n", link)

/**
\brief Macro para abrir um link
@param link O caminho para o link
@param dirX direção na coordenada x
@param dirY direção na coordenada y
*/
#define ABRIR_DIRECAO(dirX, dirY, link)																					printf("<a class=dir data-x=%d data-y=%d xlink:href=%s>\n", dirX, dirY, link)

/**
\brief Macro para fechar o link
*/
#define FECHAR_LINK																															printf("</a>\n")


/**
\brief Macro para adicionar o código javascript
*/
#define SCRIPT																																	printf("<script src=\"/script.js\"></script>\n")

/**
\brief Macro do índice da sala em que o jogador se encontra
*/
#define SALA_ATUAL																															(int) e.info.sala

/**
\brief Macro do jogador do estado e
*/
#define JOG																																			e.infojog

/**
\brief Macro do inimigo do estado 'e', de índice 'i' e na sala em que o jogador se encontra
*/
#define INI																																			e.inimigo[(int) e.info.sala][i]

/**
\brief Macro do obstáculo do estado 'e', de índice 'i' e na sala em que o jogador se encontra
*/
#define OBS																																			e.obstaculo[(int) e.info.sala][i]

/**
\brief Macro do item do estado 'e', de índice 'i' e na sala em que o jogador se encontra
*/
#define ITM																																			e.item[(int) e.info.sala][i]

/**
\brief Tamanho máximo dos nomes
*/
#define TAMANHO_NOME_MAXIMO            																					32

/**
\brief Caminho para o ficheiro que guarda os highscores
*/
#define HIGHSCORE_PATH                  																				"data/info/highscore.db"

#endif
