#include "mapa.c"

/**
@file items.h
Definição de funções sobre os items
*/

/**
\brief Caminho para a imagem do item dado o seu id
@param id Id do item
@return Caminho para a imagem do item
*/
char* item_id(int id);

/**
\brief Dano do item dado o seu id
@param id Id do item
@return dano do item
*/
int dano_arma(char id);

/**
\brief Item que cai quando se mata um inimigo
@param tipo Tipo do inimigo
@return id do item
*/
int items_drops(int tipo);

/**
\brief Coloca o item no chão
@param e Estado atual
@param x Coordenada x do jogador
@param y Coordenada y do jogador
@param id Id do item
@return Estado atualizado
*/
ESTADO deixarItem(ESTADO e, int x, int y, int id);

/**
\brief Retira o item do chão
@param e Estado atual
@param i Índice do item
@return Estado atualizado
*/
ESTADO tirarItem(ESTADO e, int i);

/**
\brief Armadura do escudo
@param id Id do item
@return Armadura do escudo
*/
int armadura_escudo(int id);

/**
\brief Adiciona o item aos equipados / inventario
@param e Estado atual
@param x Coordenada x do jogador
@param y Coordenada y do jogador
@return Estado atualizado
*/
ESTADO apanharItem(ESTADO e, int x, int y);

/**
\brief Adiciona o item aos equipados
@param e Estado atual
@return Estado atualizado
*/
ESTADO equipar(ESTADO e);

/**
\brief Remove o item do inventario
@param e Estado atual
@return Estado atualizado
*/
ESTADO deixar(ESTADO e);

/**
\brief Usa os consumiveis
@param e Estado atual
@return Estado atualizado
*/
ESTADO usar(ESTADO e);
