#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include "cgi.h"
#include "estado.h"
#include "imprime.c"

#define NUM_OBSTACULOS			25

POSICAO nova_posicao(ESTADO e) {
	int X;
	int Y;
	POSICAO novo;
	do {
		X = random() % TAM;
		Y = random() % TAM;
	} while (tem_objeto(e, X, Y) || num_a_volta(e, X, Y) > 2 || posicao_porta(X, Y) || tem_escada(e, X, Y));
	novo.x = X;
	novo.y = Y;
	novo.dir = 0;
	return novo;
}

INIMIGOS inicializar_guerreiro(int tipo, INIMIGOS inimigo){
	inimigo.vida = 40 + 30 * tipo;
	inimigo.tipo.ataque = 2 + tipo;
	inimigo.tipo.alcance = 1;
	return inimigo;
}

INIMIGOS inicializar_arqueiro(int tipo, INIMIGOS inimigo){
	inimigo.vida = 20 + (tipo - 3) * 20;
	inimigo.tipo.ataque = 2 + (tipo - 3) * 2;
	inimigo.tipo.alcance = 4;
	return inimigo;
}

INIMIGOS inicializar_mago(int tipo, INIMIGOS inimigo){
	inimigo.vida = 10 + (tipo - 5) * 10;
	inimigo.tipo.ataque = 3 + (tipo - 5) * 3;
	inimigo.tipo.alcance = 2;
	return inimigo;
}

INIMIGOS inicializar_hoplita(INIMIGOS inimigo){
	inimigo.vida = 30;
	inimigo.tipo.ataque = 4;
	inimigo.tipo.alcance = 1;
	return inimigo;
}

INIMIGOS inicializar_inimigo_outro(INIMIGOS inimigo){
	inimigo.vida = 10;
	inimigo.tipo.ataque = 1;
	inimigo.tipo.alcance = 1;
	return inimigo;
}
ESTADO inicializar_inimigo(ESTADO e, int tipo){
	POSICAO pos = nova_posicao(e);
	int i = (int) e.num[INIMIGO][SALA_ATUAL];
	INI.pos = pos;
	if(tipo < 3) //guerreiro
		INI = inicializar_guerreiro(tipo, INI);
	else if(tipo < 5) //arqueiro
		INI = inicializar_arqueiro(tipo, INI);
	else if(tipo < 8) //mago
		INI = inicializar_mago(tipo, INI);
	else if(tipo == 8) //hoplita
		INI = inicializar_hoplita(INI);
	else
		INI = inicializar_inimigo_outro(INI);
	INI.tipo.tipo = tipo;
	e.num[INIMIGO][SALA_ATUAL]++;
	return e;
}

int limite(int min,int val, int sub) {
	if (val - sub < min) return min;
	else return val - sub;
}

ESTADO novo_guerreiro(ESTADO e, int nivel, int r, int* dif){
	if (r > limite(40, 90, nivel * 5) && (*dif - 15)) {
		e = inicializar_inimigo(e, 2);
		*dif -= 15;
	}
	else if (r > limite(40, 80, nivel * 5)  && (*dif - 10)) {
		e = inicializar_inimigo(e, 1);
		*dif -= 10;
	}
	else if (r > 40 + nivel * 5 && (*dif - 5)) {
		e = inicializar_inimigo(e, 0);
		*dif -= 5;
	}
	return e;
}

ESTADO novo_arqueiro(ESTADO e, int nivel, int r, int* dif){
	if (r > limite(20, 40, nivel * 5)  && (*dif - 10)) {
		e = inicializar_inimigo(e, 4);
		*dif -= 10;
	}
	else if (r > 20 + nivel * 5 && (*dif - 5)) {
		e = inicializar_inimigo(e, 3);
		*dif -= 5;
	}
	return e;
}

ESTADO novo_mago(ESTADO e, int nivel, int r, int* dif){
	if (r > limite(0, 20, nivel * 5) && (*dif - 15)) {
		e = inicializar_inimigo(e, 7);
		*dif -= 15;
	}
	else if (r > limite(0, 10, nivel * 5)  && (*dif - 10)) {
		e = inicializar_inimigo(e, 6);
		*dif -= 10;
	}
	else if (r + nivel * 5 && (*dif - 5)) {
		e = inicializar_inimigo(e, 5);
		*dif -= 5;
	}
	return e;
}

ESTADO inicializar_inimigos(ESTADO e,int nivel){
	int dif = nivel * 10 + 10;
	while(dif > 0){
		int r = rand() % 101;
		//hoplita 100...90
		if (r > 90) {
			e = inicializar_inimigo(e, 8);
			dif -= 10;
		}
		//guerreiro 90...40
		if(r > 40)
			e = novo_guerreiro(e, nivel, r, &dif);
		//arqueiro 40...20
		else if(r > 20)
			e = novo_arqueiro(e, nivel, r, &dif);
		//mago 20...0
		else
			e = novo_mago(e, nivel, r, &dif);
	}
	return e;
}

ESTADO inicializar_obstaculo(ESTADO e){
	POSICAO pos = nova_posicao(e);
	int i = (int) e.num[OBSTACULO][SALA_ATUAL];
	OBS.pos = pos;
	e.num[OBSTACULO][SALA_ATUAL]++;
	return e;
}

ESTADO inicializar_obstaculos(ESTADO e,int num){
	int i;
	for(i = 0; i < num; i++){
		e = inicializar_obstaculo(e);
	}
	return e;
}

INFOJOGADOR inicializarJogador(){
	INFOJOGADOR jog;
	jog.pos.x = TAM/2;
	jog.pos.y = TAM/2;
	jog.pos.dir = 0;
	jog.vida = 100;
	jog.armadura = 0;
	jog.efeitos = 0;

	jog.inventario = 0;
	jog.equipados[1] = 0;
	jog.consumiveis = 0;

	return jog;
}

void inicializarEstado(ESTADO e){
	memset(&e, 0, sizeof(struct estado));
}

ESTADO inicializar(INFO info, INFOJOGADOR jog) {
	//gerais
	ESTADO e;
	inicializarEstado(e);
	e.info = info;

	//escada
	int X,Y;
	do {
		e.escada.sala = random() % NUM_SALAS;
	} while (e.escada.sala == e.info.sala);
	do {
		X = random() % TAM;
		Y = random() % TAM;
	} while (posicao_porta(X, Y));
	e.escada.pos.x = X;
	e.escada.pos.y = Y;

	//sala
	e.salas[SALA_ATUAL].visited = 1;
	e.num[JOGADOR][SALA_ATUAL] = 1;

	//jogador
	JOG = jog;

	//obstaculos
	e = inicializar_obstaculos (e, NUM_OBSTACULOS);

	//inimigos
	e = inicializar_inimigos (e, e.info.nivel);
	return e;
}

ESTADO inicializar_sala(ESTADO e, int x, int y, int sala) {
	e.info.sala = sala;
	JOG.pos.x = x;
	JOG.pos.y = y;
	if(!e.salas[sala].visited){
		e.salas[sala].visited = 1;
		e.num[JOGADOR][sala] = 1;
		e = inicializar_obstaculos(e, NUM_OBSTACULOS);
		e = inicializar_inimigos(e, e.info.nivel);
	}

	return e;
}

ESTADO mudar_sala(ESTADO novo, int x, int y, int sala) {
	switch (ir_porta(x, y)) {
		//cima
		case -3:
			return inicializar_sala(novo, TAM/2, TAM - 1, sala);
			break;
		//baixo
		case  3:
			return inicializar_sala(novo, TAM/2, 0, sala);
			break;
		//esquerda
		case -1:
			return inicializar_sala(novo, TAM - 1, TAM/2, sala);
			break;
		//direita
		case 1:
			return inicializar_sala(novo, 0, TAM/2, sala);
			break;
	}
	return novo;
}

ESTADO ler_estado(char* args) {
	if(args == 0) {
		INFO info;
		info.nivel = 0;
		info.sala = NUM_SALAS / 2;
		info.pontuacao = 0;
		return inicializar(info, inicializarJogador());
	}
	return str2estado(args);
}


int obter_id(){
	FILE* f;
	char* uid = getCookie("uid");
	unsigned int id;
	char fileName[15];
	if(uid){
		sscanf(uid,"%X",&id);
	} else {
		id = rand();
	}
	sprintf(fileName,"data/%X",id);
	f = fopen(fileName,"r");
	if(f){
		if(!uid){
			//id já ocupado
			free(uid);
			return obter_id();
		}
	} else {
		//criar novo id
		f = fopen(fileName,"w");
		sprintf(fileName,"%X",id);
		setCookie("uid",fileName);
	}
	fclose(f);
	free(uid);
	return id;
}

char* recuperar_estado(int id){
	char fileName[15];
	sprintf(fileName,"data/%X",id);
	FILE* f = fopen(fileName,"r");
	char* mapa = malloc(MAX_BUFFER);
	if(fgets(mapa,MAX_BUFFER,f) == 0){
		fclose(f);
		return 0;
	}
	fclose(f);
	return mapa;
}

void escrever_estado(int id, ESTADO e){
	char fileName[15];
	sprintf(fileName,"data/%X",id);
	FILE* f = fopen(fileName,"w");
	fprintf(f, "%s", estado2str(e));
}

int ler_comandos(int* comando, int* x, int* y){
    char* get = getenv("QUERY_STRING");
    if(get){
        return sscanf(get,"%d,%d,%d", comando, x, y);
    }
    return 0;
}

ESTADO moverInimigo(ESTADO e, int i, int mapa[TAM][TAM]){
	int dx, dy, coefNovo, posicao_possivel;
	int coefAtual = TAM * 100;
	int posX = INI.pos.x, posY = INI.pos.y;
	int x = INI.pos.x, y = INI.pos.y;
	for(dx = -1; dx <= 1; dx++){
		for(dy = -1; dy <= 1; dy++){
			coefNovo = mapa[x + dx][y + dy] * 100 - dist(INI.pos, JOG.pos);
			posicao_possivel = posicao_valida(x + dx, y + dy) && !tem_objeto(e, x + dx, y + dy) && !posicao_porta(x + dx, y + dy);
			if(posicao_possivel && coefNovo < coefAtual){
				posX = x + dx;
				posY = y + dy;
				coefAtual = coefNovo;
			}
		}
	}
	INI.pos.x = posX;
	INI.pos.y = posY;
	return e;
}

ESTADO moverInimigos(ESTADO e) {
	int i;
	int* mapas[2][5] = {{0}};
	for(i = 0; i < e.num[INIMIGO][SALA_ATUAL]; i++){
		int mapa[TAM][TAM];
		obterMapa(e, mapa, mapas, 0, INI.tipo.alcance);
		if(mapa[(int) INI.pos.x][(int) INI.pos.y]){
			e = moverInimigo(e, i, mapa);
		} else {
			e = atacarJogador(e, mapa);
		}
	}
	return e;
}


int pontuacao_inimigo(int id) {
	if (id < 3) return 1 + id;
	if (id < 5) return id - 2;
	if (id < 8) return id - 4;
	return 2;
}

ESTADO matarInimigo(ESTADO e, int i, int x, int y){
	//deixar item
	char id = items_drops(INI.tipo.tipo);
	if (id) e = deixarItem(e, x, y, id);

	for(; i < e.num[INIMIGO][SALA_ATUAL]; i++){
	INI = e.inimigo[SALA_ATUAL][i+1];
	}

	e.num[INIMIGO][SALA_ATUAL]--;
	e.info.pontuacao += pontuacao_inimigo(id);
	return e;
}

ESTADO atacarInimigo(ESTADO e, int x, int y) {
	int i;
	int dano = dano_arma(JOG.equipados[0]);
	for(i = 0; i < e.num[INIMIGO][SALA_ATUAL]; i++){
		if(posicao_igual(INI.pos, x, y)){
			INI.vida -= dano;
			if(INI.vida <= 0) e = matarInimigo(e, i, x, y);
		}
	}
	return e;
}

ESTADO nova_direcao(ESTADO e, int x){
	if (JOG.pos.x < x)
		JOG.pos.dir = 0;
	else
		JOG.pos.dir = 1;
	return e;
}

ESTADO novo_estado(ESTADO e, int x, int y) {
	int sala = e.info.sala + ir_porta(x, y);
	int sala_disponivel = tem_sala(e.info.sala, sala);
	e = nova_direcao(e, x); //direcao do jogador
	if(ir_porta(x, y)){ //entrar na porta
		if(sala_disponivel)
			return mudar_sala(e, x, y, sala);
	} else if(ir_escada(e, x, y)){ //entrar nas escadas
		e.info.nivel++;
		e.info.pontuacao += e.info.nivel * 2;
		e = inicializar(e.info, JOG);
	} else if(tem_inimigo(e, x, y)) //atacar o inimigo
		e = atacarInimigo(e, x, y);
	else { //mover
		JOG.pos.x = x; JOG.pos.y = y;
		if (tem_item(e, x, y)) //apanhar item
			e = apanharItem(e, x, y);
	}
	e = moverInimigos(e);
	return e;
}

ESTADO executar_comando(ESTADO e, int comando, int x, int y){
	switch (comando) {
		case 0:	//mover
			if(!invalido(x, y, e) && !tem_jogador(e, x, y) && JOG.vida > 0)
				return novo_estado(e, x, y);
		case 1:	//equipar/usar item inventario
			return novo_estado(equipar(e), JOG.pos.x, JOG.pos.y);
		case 2: //deixar item do inventario
			if(tem_item(e, JOG.pos.x, JOG.pos.y)){
				return novo_estado(deixar(e), JOG.pos.x, JOG.pos.y);
			} else {
				return deixar(e);
			}
		case 3: //usar consumivel
			return novo_estado(usar(e), JOG.pos.x, JOG.pos.y);
		case 4: //ativar / desativar ajudas
			return ajudas(e);
	}
	return e;
}

int main() {
	int comando, x, y;
	srandom(time(NULL));
	int id = obter_id();
	char* estado = recuperar_estado(id);
	ESTADO e = ler_estado(estado);
	ESTADO anterior = e;
	if(ler_comandos(&comando,&x, &y) == 3)
  		e = executar_comando(e, comando, x, y);
	escrever_estado(id, e);
	free(estado);
	COMECAR_HTML;
	ABRIR_SVG(1300, 650);
	imprime(anterior, e);
	FECHAR_SVG;
	SCRIPT;
	if(JOG.vida <= 0){
		printf("<script>if(nome = prompt('Coloque aqui o seu nome')){location.href='/cgi-bin/highscore?' + nome;}else{location.href='/cgi-bin/highscore'}</script>\n");
	}
	return 0;
}
