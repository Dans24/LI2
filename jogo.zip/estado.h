#ifndef ___ESTADO_H___
#define ___ESTADO_H___

/**
@file estado.h
Definição do estado e das funções que convertem estados em strings e vice-versa
*/

/** \brief O nº máximo de obstáculos */
#define MAX_OBJ							30

/** \brief O nº de tipos de objetos no jogo */
#define NUM_OBJECTOS				4

/** \brief Indíce do jogador */
#define JOGADOR							0

/** \brief Índice dos inimigos */
#define INIMIGO							1

/** \brief Índice dos obstaculos */
#define OBSTACULO						2

/** \brief Índice dos items */
#define NITEM 							3

/** \brief Número de salas disponíveis */
#define NUM_SALAS 					9

/**
\brief Estrutura que armazena informção do jogo
*/
typedef struct info {
	/** \brief Informação sobre o nível atual do jogador */
	char nivel;
	/** \brief Informação sobre a sala atial do jogador */
	char sala;
	/** \brief Informação sobre a pontuação */
	char pontuacao;
	/** \brief Informação sobre se as ajudas estão ativadas */
	char ajudas;
} INFO;

/**
\brief Estrutura que armazena informção do jogo
*/
typedef struct info_sala {
	/** \brief Informação sobre o tipo da sala */
	char tipo;
	/** \brief Informação sobre se a sala já foi visitada */
	char visited;
} SALA;

/**
\brief Estrutura que armazena informação da posição dos objetos
*/
typedef struct posicao {
	/** \brief Informação sobre a coordenada x */
	char x;
	/** \brief Informação sobre a coordenada y */
	char y;
	/** \brief Informação sobre a direção */
	char dir;
} POSICAO;

/**
\brief Estrutura que armazena informação do tipo de inimigo
*/
typedef struct tipo {
	/** \brief Informação sobre o dano do inimigo */
	char ataque;
	/** \brief Informação sobre o alcance do ataque */
	char alcance;
	/** \brief Informação sobre o tipo do inimigo */
	char tipo;
} TIPO;

/**
\brief Estrutura que armazena informção da escada
*/
typedef struct info_escada {
	/** \brief Informação sobre a posição da escada */
	POSICAO pos;
	/** \brief Informação sobre a sala onde se encontrado a escada */
	char sala;
} ESCADA;

/**
\brief Estrutura que armazena informação dos inimigos
*/
typedef struct inimigos {
	/** \brief Informação sobre a posição do inimigo */
	POSICAO pos;
	/** \brief Informação sobre o tipo do inimigo */
	TIPO tipo;
	/** \brief Informação sobre a vida atual do inimigo */
	char vida;
	/** \brief Informação sobre os efeitos sobre o inimigo */
	char efeitos;
} INIMIGOS;


/**
\brief Estrutura que armazena informação dos obstaculos
*/
typedef struct obstaculos {
	/** \brief Informação sobre a posição do obstaculo */
	POSICAO pos;
} OBSTACULOS;

/**
\brief Estrutura que armazena informação dos items
*/
typedef struct items {
	/** \brief Informação sobre o id do item */
	char id;
	/** \brief Informação sobre a posição da item */
	POSICAO pos; //dir = id
} ITEMS;

/**
\brief Estrutura que armazena o estado do jogador
*/
typedef struct jogador {
	/** \brief Informação sobre a posição do jogador */
	POSICAO pos;
	/** \brief Informação sobre a vida atual do jogador */
	char vida;
	/** \brief Informação sobre a durabilidade da armadura */
	char armadura;
	/** \brief Informação sobre os efeitos sobre o jogador */
	char efeitos;
	/** \brief Informação sobre o item guardado em inventário */
	char inventario;
	/** \brief Informação sobre os itens equipados pelo jogador */
	/** \brief O elemento 0 do array é arma */
	/** \brief O elemento 1 do array é o escudo */
	char equipados[2];
	/** \brief Informação sobre os consumiveis guardados pelo jogador */
	char consumiveis;
} INFOJOGADOR;

/**
\brief Estrutura que armazena o estado do jogo
*/
typedef struct estado {
	/** \brief Informação da partida */
	INFO info;
	/** \brief Informação sobre as salas */
	SALA salas[NUM_SALAS];
	/** \brief Informação sobre o alçapão */
	ESCADA escada;
	/** \brief O nº de objetos */
	char num[NUM_OBJECTOS][NUM_SALAS];
	/** \brief Array com os stats dos inimigos */
	INIMIGOS inimigo[NUM_SALAS][MAX_OBJ];
	/** \brief Array com os stats dos obstaculso */
	OBSTACULOS obstaculo[NUM_SALAS][MAX_OBJ];
	/** \brief Informação sobre os items */
	ITEMS item[NUM_SALAS][MAX_OBJ];
	/** \brief Informação sobre o jogador */
	INFOJOGADOR infojog;
} ESTADO;

/**
\brief Função que converte um estado numa string
@param e O estado
@returns A string correspondente ao estado e
*/
char *estado2str(ESTADO e);

/**
\brief Função que converte uma string num estado
@param argumentos Uma string contendo os argumentos passados à CGI
@returns O estado correspondente à string dos argumentos
*/
ESTADO str2estado(char *argumentos);

/**
\brief Função que cria um cookie no utilizador
@param nome Uma string com o nome do cookie
@param valor Uma string com o valor da cookie
*/
void setCookie(char* nome, char* valor);

/**
\brief Função que retorna o valor da cookie
@param nome Uma string com o nome da cookie
@returns endereço da string com o valor da cookie
@returns NULL se não existir cookie com esse nome
*/
char* getCookie(char* nome);

/**
\brief Função que retorna o valor da cookie
@param nome Uma string com o nome da cookie
@param cookie Uma string com todos os valores da cookie (deixar nulo para obter a cookie)
@returns endereço da string com o valor da cookie
@returns NULL se não existir cookie com esse nome
*/
char* getCookieFrom(char* nome, char* cookie);

#endif
