#include "items.c"

/**
@file imprime.h
Definição de funções que imprimem na página
*/

/**
\brief Tamanho dos quadrados
*/
#define ESCALA					    50

/**
\brief Distância à borda da página em x e em y
*/
#define OFFSET					    50

/**
\brief Número de inimigos
*/
#define NUM_INIMIGOS			  2

/**
\brief Número de obstáculos
*/
#define NUM_OBSTACULOS			25

/**
\brief Imprime o fundo no jogo
*/
void imprime_fundo();

/**
\brief imprime as portas de uma sala
@param sala Índice da sala
*/
void imprime_portas(int sala);

/**
\brief Imprime uma casa da sala no jogo
@param x Coordenada x
@param y Coordenada y
*/
void imprime_casa(int x, int y);

/**
\brief Imprime todas as casas da sala no jogo
*/
void imprime_casas();

/**
\brief Imprime a escada da sala se houver
@param e Estado atual
*/
void imprime_escadas(ESTADO e);

/**
\brief Imprime os items da sala no jogo
@param e Estado atual
*/
void imprime_items(ESTADO e);

/**
\brief Imprime o jogador no jogo
@param anterior Estado anterior
@param e Estado atual
*/
void imprime_jogador(ESTADO anterior, ESTADO e);

/**
\brief Imprime a barra de vida dos inimigos
@param vida Vida atual do inimigo
@param p Posição atual do inimigo
@param espessura Espessura da barra de vida
*/
void imprime_vida(int vida, POSICAO p, int espessura);

/**
\brief Imprime os inimigos da sala
@param anterior Estado anterior
@param e Estado atual
*/
void imprime_inimigos(ESTADO anterior, ESTADO e);

/**
\brief Imprime os obstaculos da sala
*/
void imprime_obstaculos(ESTADO e);

/**
\brief Imprime todos os objetos da sala
@param anterior Estado anterior
@param e Estado atual
*/
void imprime_objetos(ESTADO anterior, ESTADO e);

/**
\brief Imprime as posições que o jogador pode mover-se
@param x Coordenada x
@param y Coordenada y
*/
void imprime_mov(int x, int y);

/**
\brief Imprime as posições que pode atacar
@param x Coordenada x
@param y Coordenada y
*/
void imprime_mov_ataque(int x, int y);

/**
\brief Imprime as posições que pode apanhar itens
@param x Coordenada x
@param y Coordenada y
*/
void imprime_mov_apanha(int x, int y);

/**
\brief Imprime as posições que pode entrar nas portas
@param x Coordenada x
@param y Coordenada y
*/
void imprime_mov_porta(int x, int y);

/**
\brief Imprime a ação que pode realizar na casa de coordenadas (x,y)
@param e Estado atual
@param dx Direção em x
@param dy Direção em y
*/
void imprime_movimento(ESTADO e, int dx, int dy);

/**
\brief Imprime as ações que pode realizar
@param e Estado atual
*/
void imprime_movimentos(ESTADO e);

/**
\brief Imprime os botões do inventario
@param e Estado atual
*/
void imprime_usarinv(ESTADO e);

/**
\brief Imprime o stats do jogador
@param e Estado atual
*/
void imprime_stats(ESTADO e);

/**
\brief Imprime as ajudas no mapa
@param e Estado atual
*/
void imprime_ajudas(ESTADO e);

/**
\brief Imprime o botão que ativa e desativa as ajudas
*/
void imprime_butao_ajudas();

/**
\brief Ativa e desativa as ajudas
@param e Estado atual
@return Estado atualizado
*/
ESTADO ajudas(ESTADO e);

/**
\brief Imprime o jogo
@param anterior Estado anterior
@param e Estado atual
*/
void imprime(ESTADO anterior, ESTADO e);
