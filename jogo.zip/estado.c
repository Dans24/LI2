#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "estado.h"
#include "cgi.h"

char *estado2str(ESTADO e) {
	static char buffer[MAX_BUFFER];
	unsigned char *p = (unsigned char *) &e;
	unsigned int i;

	buffer[0] = 0;

	for(i = 0; i < sizeof(ESTADO); i++)
		sprintf(buffer, "%s%02x", buffer, p[i]);

	return buffer;
}

ESTADO str2estado(char *argumentos) {
	ESTADO e;
	unsigned char *p = (unsigned char *) &e;
	unsigned int i;

	for(i = 0; i < sizeof(ESTADO); i++, argumentos += 2) {
		unsigned int d;
		sscanf(argumentos, "%2x", &d);
		p[i] = (unsigned char) d;
	}

	return e;
}

void setCookie(char* nome, char* valor){
	printf("Set-Cookie: %s=%s\n", nome, valor);
}

char* getCookieFrom(char* nome, char* cookie){
	//Define variaveis
	char* destino;
  char str_nome[100];
  char str_valor[100];
  char str_resto[100];
	//Sai se não tiver cookie
	if(!cookie){
		return 0;
	}
	//Descodifica os cookies
	int num_var = sscanf(cookie, "%[^=]= %[^;];%s", str_nome, str_valor, str_resto);
	//Se não tiver componentes suficientes sai
  if(num_var < 2){
		return 0;
	}
  if(!strcmp(nome,str_nome)){
		//Caso o nome do cookie seja igual ao que queremos, ele irá alocar o valor desse cookie
		destino = malloc(strlen(str_valor));
    strcpy(destino, str_valor);
    return destino;
	}
	//Caso ainda não tenha encontrado, continua a procurar no resto
	return getCookieFrom(nome, str_resto);
}

char* getCookie(char* nome){
	return getCookieFrom(nome, getenv("HTTP_COOKIE"));
}
