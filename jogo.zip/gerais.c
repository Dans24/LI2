#include "estado.h"
#include "cgi.h"
#define TAM						11

int posicao_valida(int x, int y) {
	return x >= 0 && y >= 0 && x < TAM && y < TAM;
}

int posicao_igual(POSICAO p, int x, int y){
	return p.x == x && p.y == y;
}

int posicao_porta(int x,int y) {
	int porta_esquerda = x == 0 && y == (TAM / 2);
	int porta_direita = x == (TAM - 1) && y == (TAM / 2);
	int porta_cima = x == (TAM/2) && y == 0;
	int porta_baixo = x == (TAM/2) && y == (TAM - 1);
	return porta_baixo || porta_cima || porta_direita || porta_esquerda;
}


int ir_escada(ESTADO e, int x, int y){
	if(x == e.escada.pos.x && y == e.escada.pos.y && e.escada.sala == e.info.sala)
		return 1;
	return 0;
}

int tem_sala(int atual_sala, int proxima_sala) {
	if(proxima_sala < 0 || proxima_sala >= NUM_SALAS)
		return 0;
	int num_linhas = sqrt(NUM_SALAS);
	//Evita que ele passe das salas laterais para a proxima (ou anterior) linha
	int delta = (proxima_sala % num_linhas) - (atual_sala % num_linhas);
	if(abs(delta) > 1)
		return 0;
	return 1;
}

int tem_jogador(ESTADO e,int x, int y){
	if(posicao_igual(JOG.pos, x, y))
		return 1;
	return 0;
}

int tem_inimigo(ESTADO e, int x, int y){
	int i;
	for(i = 0; i < e.num[INIMIGO][SALA_ATUAL]; i++)
		if(posicao_igual(INI.pos, x, y))
			return 1;
	return 0;
}

int tem_item(ESTADO e, int x, int y){
	int i;
	for(i = 0; i < e.num[NITEM][SALA_ATUAL]; i++)
		if(posicao_igual(ITM.pos, x, y))
			return 1;
	return 0;
}

int tem_obstaculo(ESTADO e, int x, int y){
	int i;
	for(i = 0; i < e.num[OBSTACULO][SALA_ATUAL]; i++)
		if(posicao_igual(OBS.pos, x, y))
			return 1;
	return 0;
}

int tem_objeto(ESTADO e,int x, int y){
	return tem_jogador(e, x, y) || tem_inimigo(e, x, y) || tem_obstaculo(e, x, y);
}

int tem_escada(ESTADO e,int x, int y){
	int dx,dy;
	if(e.info.sala == e.escada.sala)
		for(dx = -1; dx <= 1; dx++)
			for(dy = -1; dy <= 1; dy++)
				if(e.escada.pos.x == x + dx && e.escada.pos.y == y + dy)
					return 1;
	return 0;
}


int a_volta(POSICAO p, int x, int y){
	if(p.x >= x - 1 && p.x <= x + 1 && p.y >= y - 1 && p.y <= y + 1)
		return 1;
	return 0;
}

int num_a_volta(ESTADO e,int x, int y){
	int i;
	int c = 0;
	for(i = 0; i < e.num[OBSTACULO][SALA_ATUAL]; i++){
		if(a_volta(OBS.pos, x, y))
			c++;
	}
	return c;
}

int ir_porta(int x, int y) {
	//Porta esquerda
	if(x == -1 && y == (TAM/2))
		return -1;
	// Porta direita
	if(x == TAM && y == (TAM/2))
		return 1;
	// Porta Cima
	if(x == (TAM/2) && y == -1)
		return -3;
	// Porta Baixo
	if(x == (TAM/2) && y == TAM)
		return 3;
	return 0;
}

int invalidoDistancia(int x, int y, ESTADO e){
	int deltaX = abs(JOG.pos.x - x);
	int deltaY = abs(JOG.pos.y - y);
	if(deltaX <= 1 && deltaY <= 1)
		return 0;
	if(deltaX > 3 || deltaY > 3)
		return 1;
	if(tem_inimigo(e, x, y))
		return 0;
	return 1;
}

int invalido(int x, int y, ESTADO e){
	int deltaX = abs(JOG.pos.x - x);
	int deltaY = abs(JOG.pos.y - y);
	int sala = e.info.sala + ir_porta(x, y);
	int sala_disponivel = tem_sala(e.info.sala, sala);
	if(!ir_porta(x, y) || !sala_disponivel){
		if(!posicao_valida(x, y))
			return 1;
		if(tem_obstaculo(e, x, y))
			return 1;
	}
	if(JOG.equipados[0] > 80)
		return invalidoDistancia(x, y, e);
	if(deltaX > 1 || deltaY > 1)
		return 1;
	return 0;
}
