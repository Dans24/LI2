#include "estado.h"
#include "cgi.h"

/**
@file gerais.h
Definição de funções sobre o posicionamento
*/

/**
\brief Numero de quadrados por cada linha do mapa
*/
#define TAM						11

/**
\brief Indica se a posição está dentro do campo de jogo
@param x Coordenada x
@param y Coordenada y
@return 1 se estiver dentro do campo de jogo, 0 se não estiver
*/
int posicao_valida(int x, int y);

/**
\brief Indica se duas posições são iguais
@param p Posição
@param x Coordenada x
@param y Coordenada y
@return 1 se a posição fôr igual, 0 se não fôr
*/
int posicao_igual(POSICAO p, int x, int y);

/**
\brief Indica se a posição é entrada para uma porta
@param x Coordenada x
@param y Coordenada y
@return 1 se fôr entrada, 0 se não fôr
*/
int posicao_porta(int x,int y);

/**
\brief Indica se a posição é entrada para a escada
@param e Estado atual
@param x Coordenada x
@param y Coordenada y
@return 1 se fôr entrada, 0 se não fôr
*/
int ir_escada(ESTADO e, int x, int y);

/**
\brief Indica se a sala existe
@param atual_sala Índice da sala atual do jogador
@param proxima_sala Índice da sala que se quer verificar se existe
@return 1 se tiver sala, 0 se não tiver
*/
int tem_sala(int atual_sala, int proxima_sala);

/**
\brief Indica se existe um jogador na posição
@param e Estado atual
@param x Coordenada x
@param y Coordenada y
@return 1 se tiver jogador, 0 se não tiver
*/
int tem_jogador(ESTADO e,int x, int y);

/**
\brief Indica se existe um inimigo na posição
@param e Estado atual
@param x Coordenada x
@param y Coordenada y
@return 1 se tiver inimigo, 0 se não tiver
*/
int tem_inimigo(ESTADO e, int x, int y);

/**
\brief Indica se existe um item na posição
@param e Estado atual
@param x Coordenada x
@param y Coordenada y
@return 1 se tiver item, 0 se não tiver
*/
int tem_item(ESTADO e, int x, int y);

/**
\brief Indica se existe um obstáculo na posição
@param e Estado atual
@param x Coordenada x
@param y Coordenada y
@return 1 se tiver obstáculo, 0 se não tiver
*/
int tem_obstaculo(ESTADO e, int x, int y);

/**
\brief Indica se existe um objeto na posição
@param e Estado atual
@param x Coordenada x
@param y Coordenada y
@return 1 se tiver objeto, 0 se não tiver
*/
int tem_objeto(ESTADO e,int x, int y);

/**
\brief Indica se tem escada à volta da posição
@param e Estado atual
@param x Coordenada x
@param y Coordenada y
@return 1 se tiver escadas, 0 se não tiver escadas
*/
int tem_escada(ESTADO e,int x, int y);

/**
\brief Indica se as coordenadas (x,y) ficam juntas ao jogador
@param p Posição do jogador
@param x Coordenada x
@param y Coordenada y
@return 1 se fica à volta do jogador, 0 se não fica à volta do jogador
*/
int a_volta(POSICAO p, int x, int y);

/**
\brief Indica quantos obstáculos existe à volta da posição
@param e Estado atual
@param x Coordenada x
@param y Coordenada y
@return Número de obstáculos à volta da posição
*/
int num_a_volta(ESTADO e,int x, int y);

/**
\brief Indica a variação do índice da sala
@param x Coordenada x
@param y Coordenada y
@returns Variação no índice da sala
*/
int ir_porta(int x, int y);

/**
\brief Indica se a posição é invalida
@param x Coordenada x
@param y Coordenada y
@param e Estado atual
@return 1 se inválido e 0 se válido
*/
int invalido(int x, int y, ESTADO e);
