#include "mapa.c"

char* item_id(int id){
	char* img_arma[] = {"1Espada_ferrugenta.png", "1Espada_de_osso.png", "1Lanca_de_osso.png", "1Espada_de_ferro.png", "1Machado_de_ferro.png", "1Lanca_grega.png"};
	char* img_arco[] = {"2Arco_de_madeira.png", "2Arco_de_osso.png", "2Arco_longo.png"};
	char* img_escudo[] = {"Escudo_de_madeira.png", "Escudo_de_ferro.png", "Escudo_hoplita.png"};
	char* img_consumivel[] = {"pocao_vida1.png", "pocao_vida2.png", "pocao_vida3.png", "pocao_vida4.png"};

	if (id < 80) return img_arma[id - 1];
	else
	if (id < 100) return img_arco[id - 81];
	else
	if (id < 110) return img_escudo[id - 101];
	else
	return img_consumivel[id - 111];
}

int dano_arma(char id) {
	if(id > 0 && id <= 6)
		return 20 + id * 3;

	if(id > 80 && id <= 83)
		return 10 + (id - 80) * 5;

	return 15;
}

int drop_guerreiro_1(){
	int id = 0;
	int r = rand() % 101;
	if (r > 80) id = 101;
	else
	if (r > 70) id = 2;
	else
	if (r > 60) id = 3;
	else
	if (r > 40) id = 1;
	return id;
}

int drop_guerreiro_2(){
	int id = 0;
	int r = rand() % 101;
	if (r > 90) id = 102;
	else
	if (r > 80) id = 101;
	else
	if (r > 70) id = 3;
	else
	if (r > 60) id = 2;
	return id;
}

int drop_guerreiro_3(){
	int id = 0;
	int r = rand() % 101;
	if (r > 80) id = 102;
	else
	if (r > 70) id = 4;
	else
	if (r > 60) id = 5;
	return id;
}

int drop_arqueiro_1(){
	int id = 0;
	int r = rand() % 101;
	if (r > 80) id = 81;
	else
	if (r > 70) id = 82;
	return id;
}

int drop_arqueiro_2(){
	int id = 0;
	int r = rand() % 101;
	if (r > 80) id = 81;
	else
	if (r > 70) id = 82;
	else
	if (r > 60) id = 83;
	return id;
}

int drop_mago_1(){
	int id = 0;
	int r = rand() % 101;
	if (r > 50) id = 111;
	return id;
}

int drop_mago_2(){
	int id = 0;
	int r = rand() % 101;
	if (r > 50) id = 112;
	return id;
}

int drop_mago_3(){
	int id = 0;
	int r = rand() % 101;
	if (r > 50) id = 113;
	return id;
}

int drop_hoplite(){
	int id = 103;
	int r = rand() % 101;
	if (r > 30) id = 6;
	return id;
}

int drop_guerreiros(int tipo){
	int id = 0;
	switch (tipo) {
		case 0:
			id = drop_guerreiro_1();
			break;
		case 1:
			id = drop_guerreiro_2();
			break;
		case 2:
			id = drop_guerreiro_3();
			break;
	}
	return id;
}

int drop_arqueiros(int tipo){
	int id = 0;
	switch(tipo){
		case 3:
			id = drop_arqueiro_1();
			break;
		case 4:
			id = drop_arqueiro_2();
			break;
	}
	return id;
}

int drop_magos(int tipo){
	int id = 0;
	switch(tipo){
		case 5:
			id = drop_mago_1();
			break;
		case 6:
			id = drop_mago_2();
			break;
		case 7:
			id = drop_mago_3();
			break;
	}
	return id;
}

int items_drops(int tipo) {
	int id = 0;
	//guerreiro
	if(tipo < 3)
		id = drop_guerreiros(tipo);
	//arqueiro
	else if(tipo < 5)
		id = drop_arqueiros(tipo);
	//mago
	else if(tipo < 8)
		id = drop_magos(tipo);
	//hoplita
	else if(tipo == 8)
		id = drop_hoplite();
	return id;
}

ESTADO deixarItem(ESTADO e, int x, int y, int id) {
	int n = e.num[NITEM][SALA_ATUAL];
				e.item[SALA_ATUAL][n].pos.x = x;
				e.item[SALA_ATUAL][n].pos.y = y;
				e.item[SALA_ATUAL][n].pos.dir = id;
				e.num[NITEM][SALA_ATUAL]++;
		return e;
}

ESTADO tirarItem(ESTADO e, int i){
	for(; i < e.num[NITEM][SALA_ATUAL]; i++){
	ITM = e.item[SALA_ATUAL][i+1];
	}
	e.num[NITEM][SALA_ATUAL]--;
	return e;
}

int armadura_escudo(int id) {
	if (id == 0) return 0;
	return (id - 100) * 20;
}


ESTADO apanharItem(ESTADO e, int x, int y) {
	int i;
	for(i = 0; i < e.num[NITEM][SALA_ATUAL]; i++){
		if(posicao_igual(ITM.pos, x, y)){
			int id = ITM.pos.dir;
			if (id <= 100 && JOG.equipados[0] == 0) {
				//apanhar e equipar arma
				JOG.equipados[0] = id;
				e = tirarItem(e, i);
			} else
			if (id > 100 && id <= 110 && JOG.equipados[1] == 0) {
				//apanhar e equipar escudo
				JOG.equipados[1] = id;
				JOG.armadura = armadura_escudo(id);
				e = tirarItem(e, i);
			} else
			if (id > 110 && JOG.consumiveis == 0){
				//apanhar consumivel
				JOG.consumiveis = id;
				e = tirarItem(e, i);
			} else
			if (JOG.inventario == 0) {
				//por no inventario
				JOG.inventario = ITM.pos.dir;
				e = tirarItem(e, i);
			}
		}
	}
	return e;
}

ESTADO equipar(ESTADO e) {
	char inv = JOG.inventario;
			//equipar consumivel
		if (inv > 110) {
            	JOG.inventario = JOG.consumiveis;
            	JOG.consumiveis = inv;
            //euipar escudo
        }else
        if (inv > 100) {
            	JOG.inventario = JOG.equipados[1];
            	JOG.equipados[1] = inv;
            	JOG.armadura = armadura_escudo(inv);
            //equipar arma
        }else {
           		JOG.inventario = JOG.equipados[0];
            	JOG.equipados[0] = inv;
        }
        return e;
}

ESTADO deixar(ESTADO e) {
		e = deixarItem(e, JOG.pos.x , JOG.pos.y, JOG.inventario);
    JOG.inventario = 0;
    return e;
}

ESTADO usar(ESTADO e) {
	char id = JOG.consumiveis;
	if (id <= 114) {
		int cura = (id - 110) * 10;
		if (JOG.vida + cura >= 100) JOG.vida = 100; else JOG.vida += cura;
	}
    JOG.consumiveis = 0;
    return e;
}
