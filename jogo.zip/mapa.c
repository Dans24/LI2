#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "estado.h"
#include "cgi.h"
#include "gerais.c"



void mapaInicializar(int mapa[TAM][TAM]){
  int x, y;
  for(x = 0; x < TAM; x++){
    for(y = 0; y < TAM; y++){
      mapa[x][y] = 2 * TAM;
    }
  }
}

void mapaObstaculos(ESTADO e, int mapa[TAM][TAM]){
	int i;
	for(i = 0; i < e.num[OBSTACULO][SALA_ATUAL]; i++){
		mapa[(int) OBS.pos.x][(int) OBS.pos.y] = -1;
	}
}

void mapaCoeficiente(ESTADO e, int mapa[TAM][TAM], POSICAO posicao, int dx, int dy, int valor, int alcance, int raio_de_visao);

void mapaCaminhosRecursivo(ESTADO e, int mapa[TAM][TAM], POSICAO posicao, int valor, int alcance, int raio_de_visao){
  int dx,dy;
  for(dx = -1; dx <= 1; dx++){
    for(dy = -1; dy <= 1; dy++){
      mapaCoeficiente(e, mapa, posicao, dx, dy, valor, alcance, raio_de_visao);
    }
  }
}

int podeAtacar(int mapa[TAM][TAM], int x, int y, int dx, int dy, int distX, int distY, int obstaculo, int valor, int alcance){
  int valido = mapa[x][y] && mapa[x][y] != -1;                // A posição não é um obstáculo?
  int zona_de_ataque = !distX || !distY || distX == distY;    // A posição está na vertical/horizontal/diagonal do jogador?
  int no_alcance = distX <= alcance && distY <= alcance;      // A posição está ao alcance do jogdador?
  int origem_valida = ((!dx || !dy) || (distX && distY));     // Podia atacar na posição anterior?
  int vista = valor == 0 && origem_valida && !obstaculo;      // O jogador consegue ver a posição?
  return valido && zona_de_ataque && no_alcance && vista;
}

void mapaCoeficiente(ESTADO e, int mapa[TAM][TAM], POSICAO posicao, int dx, int dy, int valor, int alcance, int raio_de_visao){
	posicao.x += dx, posicao.y += dy;                                       // Atualiza a posição
	int x = posicao.x, y = posicao.y;
	int distX = abs(x - JOG.pos.x), distY = abs(y - JOG.pos.y);             // Distância da posição do mapa ao jogador
  int visivel = distX + distY < raio_de_visao;                            // A posição está visivel
  int inimigo = tem_inimigo(e, x - dx, y - dy);                           // Tem inimigo na posição anterior?
  if(x >= 0 && x < TAM && y >= 0 && y < TAM && visivel){                  // A posição está dentro do mapa
  	if(podeAtacar(mapa, x, y, dx, dy, distX, distY, inimigo, valor, alcance))
			valor = 0;
  	else if(valor < mapa[x][y])
			valor++;
		else
			return;
		mapa[x][y] = valor; // Atualiza o mapa
		mapaCaminhosRecursivo(e, mapa, posicao, valor, alcance, raio_de_visao);
  }
}

void mapaCoeficienteAjudas(ESTADO e, int mapa[TAM][TAM], int i, POSICAO p, int dx, int dy, int alcance, int raio_de_visao);

void mapaCaminhosRecursivoAjudas(ESTADO e, int mapa[TAM][TAM], int i, POSICAO posicao, int alcance, int raio_de_visao){
  int dx,dy;
  for(dx = -1; dx <= 1; dx++){
    for(dy = -1; dy <= 1; dy++){
      mapaCoeficienteAjudas(e, mapa, i, posicao, dx, dy, alcance, raio_de_visao);
    }
  }
}

void mapaCoeficienteAjudas(ESTADO e, int mapa[TAM][TAM], int i, POSICAO posicao, int dx, int dy, int alcance, int raio_de_visao){
  int propria_posicao = posicao.x == INI.pos.x && posicao.y == INI.pos.y;      // A posição é igual à posição do inimigo?
  int inimigo = !propria_posicao && tem_inimigo(e, posicao.x, posicao.y);      // A posição está ocupada por outro inimigo?
	posicao.x += dx, posicao.y += dy;                                            // Atualza a posição
	int x = posicao.x, y = posicao.y;
	int distX = abs(x - INI.pos.x), distY = abs(y - INI.pos.y);                  // Distância da posição ao inimigo
  int visivel = distX + distY < raio_de_visao;                                 // A posição está visivel
  if(x >= 0 && x < TAM && y >= 0 && y < TAM && visivel){
  	if(podeAtacar( mapa, x, y, dx, dy, distX, distY, inimigo, 0, alcance)){
      mapa[x][y] = 0;
      mapaCaminhosRecursivoAjudas(e, mapa, i, posicao, alcance, raio_de_visao);
    }
  }
}

void mapaCaminhos(ESTADO e, int mapa[TAM][TAM], int alcance){
  mapaCaminhosRecursivo(e, mapa, JOG.pos, 0, alcance, TAM/2);
}

void mapaCaminhosAjudas(ESTADO e, int mapa[TAM][TAM], int i, int alcance){
  mapaCaminhosRecursivoAjudas(e, mapa, i, INI.pos, alcance, TAM/2);
}

int temEspacosObstruidos(int mapa[TAM][TAM]){
  int x,y;
  for(x = 0;x < TAM; x++){
    for(y = 0;y < TAM; y++){
      if(mapa[x][y] == 2 * TAM){
        return 1;
      }
    }
  }
	return 0;
}



ESTADO atacarJogador(ESTADO e, int mapa[TAM][TAM]) {
	int i, x, y;
	for(i = 0; i < e.num[INIMIGO][SALA_ATUAL]; i++){
		int dano = INI.tipo.ataque;
		x = (int) INI.pos.x;
		y = (int) INI.pos.y;
		if(!mapa[x][y]) {
			//dano todo na armadura
			if (JOG.armadura > dano) JOG.armadura -= dano;
			//dano na armadura e vida, escudo parte
			else if (JOG.armadura > 0) {
			 JOG.vida -= (dano - JOG.armadura);
			 JOG.armadura = 0;
			 JOG.equipados[1] = 0;
			}
			//dano na vida
			else JOG.vida -= dano;
		}
	}
	return e;
}

int dist(POSICAO p1, POSICAO p2){
	return abs(p1.x - p2.x) + abs(p1.y - p2.y);
}

void obterAjuda(ESTADO e, int mapa[TAM][TAM], int i, int alcance){
	mapaInicializar(mapa);
	mapaObstaculos(e, mapa);
	mapaCaminhosAjudas(e, mapa, i, alcance);
}

void obterMapa(ESTADO e, int mapa[TAM][TAM], int* mapas[2][5], int tipo, int alcance){
	if(mapas[tipo][alcance] == 0){
		mapaInicializar(mapa);
		mapaObstaculos(e, mapa);
		mapaCaminhos(e, mapa, alcance);
		mapas[tipo][alcance] = (int*) mapa;
	}
}
