#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include "cgi.h"
#include "estado.h"
#include "imprime.c"

/**
@file jogo.h
Definição de funções principais do jogo
*/

/**
\brief Cria uma nova posição aleatória que não esteja ocupada
@param e Estado atual
@return Posição livre
*/
POSICAO nova_posicao(ESTADO e);

/**
\brief Cria um novo inimigo
@param e Estado atual
@param tipo Tipo do inimigo
@return Estado atualizado com o novo inimigo
*/
ESTADO inicializar_inimigo(ESTADO e, int tipo);


/**
\brief Subtrai dois números com limite mínimo
@param min O mínimo
@param val Valor inicial
@param sub Valor que subtrai ao valor inicial
@return Retorna val - sub caso este seja maior que min. Caso contrário min é returnado
*/
int limite(int min,int val, int sub);

/**
\brief Inicializa um novo guerreiro
@param r Número alteatório entre 0 e 100
@param dif Endereço do número de pontos disponíveis para a sala
*/
ESTADO novo_guerreiro(int r, int* dif);

/**
\brief Inicializa um novo arqueiro
@param r Número alteatório entre 0 e 100
@param dif Endereço do número de pontos disponíveis para a sala
*/
ESTADO novo_arqueiro(int r, int* dif);

/**
\brief Inicializa um novo mago
@param r Número alteatório entre 0 e 100
@param dif Endereço do número de pontos disponíveis para a sala
*/
ESTADO novo_mago(int r, int* dif);

/**
\brief Inicializa os inimigos aleatóriamente em conformidade com o nível
@param e Estado atual
@param nivel Nivel atual
@return Estado atualizado com os inimigos
*/
ESTADO inicializar_inimigos(ESTADO e,int nivel);

/**
\brief Inicializa um obstaculo
@param e Estado atual
@return Estado atualizado com o obstaculo
*/
ESTADO inicializar_obstaculo(ESTADO e);

/**
\brief Inicializa os obstaculos na sala
@param e Estado atual
@param num Número de obstáculos a inicializar
@return	Estado atualizado com os obstaculos
*/
ESTADO inicializar_obstaculos(ESTADO e,int num);

/**
\brief Inicializa o jogador
@return Informação sobre o jogador
*/
INFOJOGADOR inicializarJogador();

/**
\brief Inicializa o estado do nivel
@param info Informação da partida
@param jog Informação sobre o jogador
*/
ESTADO inicializar(INFO info, INFOJOGADOR jog);

/**
\brief Inicializa a sala
@param e Estado atual
@param x Coordenada x do jogador na sala
@param y Coordenada y do jogador na sala
@param sala Índice da sala atual
*/
ESTADO inicializar_sala(ESTADO e, int x, int y, int sala);

/**
\brief Muda de sala
@param novo Estado atual
@param x Coordenada x do jogador
@param y Coordenada y do jogador
@param sala Índice da sala atual
@return retorna o estado atualizado
*/
ESTADO mudar_sala(ESTADO novo, int x, int y, int sala);

/**
\brief Converte texto em ESTADO
@param args Texto com informação sobre o estado
@return O estado codificado em texto ou um novo estado caso texto esteja vazio
*/
ESTADO ler_estado(char* args);

/**
\brief O id do jogador
@return Retorna o número do jogador ou cria um novo
*/
int obter_id();

/**
\brief Obtem o estado codificado em texto do jogador
@param id Id do jogador
*/
char* recuperar_estado(int id);

/**
\brief Grava em ficheiro o estado do jogo
@param id Id do jogador
@param e Estado atual
*/
void escrever_estado(int id, ESTADO e);

/**
\brief Preenche as variaveis com dados vindos do GET
@param comando Variável que guarda o índice do comando
@param x Variável que guarda a coordenada x
@param y Variável que guarda a coordenada y
@return Número de parametros preenchidos
*/
int ler_comandos(int* comando, int* x, int* y);

/**
\brief Move os inimigos
@param e Estado atual
@return Estado atualizado
*/
ESTADO moverInimigos(ESTADO e);

/**
\brief Remove um inimigo
@param e Estado atual
@param i Índice do inimigo a remover
@param x Coordenada x do inimigo
@param y Coordenada y do inimigo
*/
ESTADO matarInimigo(ESTADO e, int i, int x, int y);

/**
\brief Tira vida a um inimigo e remove-o se a vida fôr menor ou igual a 0
@param e Estado atual
@param x Coordenada x
@param y Coordenada y
*/
ESTADO atacarInimigo(ESTADO e, int x, int y);

/**
\brief Atualiza o estado
@param e Estado atual
@param x Nova coordenada x do jogador
*/
ESTADO nova_direcao(ESTADO e, int x);

/**
\brief Atualiza o estado
@param e Estado atual
@param x Nova coordenada x do jogador
@param y Nova coordenada y do jogador
*/
ESTADO novo_estado(ESTADO e, int x, int y);

/**
\brief Atualiza o estado e imprime o mapa
*/
int main();
