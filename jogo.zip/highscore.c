#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "cgi.h"
#include "estado.h"

char* urlDecode(char* string){
  int r = 0, w = 0;
  unsigned int valor;
  char* buffer = malloc(10000);
  while(string[r]){
    if(string[r] == '+'){
      buffer[w] = ' ';
      r++;
    } else if(string[r] == '%'){
      sscanf(string + r, "%%%2X", &valor);
      buffer[w] = valor;
      r += 3;
    } else {
      buffer[w] = string[r];
      r++;
    }
    w++;
  }
  buffer[w] = 0;
  return buffer;
}

char* HTMLentitles(char* string){
    int r = 0;
    int w = 0;
    char* buffer = malloc(MAX_BUFFER);
    while(string[r]){
        if(string[r] == '<'){
          sprintf(buffer + w,"&#60");
          w += 4;
        } else if(string[r] == '>'){
          sprintf(buffer + w,"&#62");
          w += 4;
        } else {
          buffer[w] = string[r];
          w++;
        }
        r++;
    }
    buffer[w] = 0;
    return buffer;
}

char* truncate(char* str, int tam){
  int i = 0;
  while(str[i] && i < tam){
    if(str[i] == '%'){
      tam += 2;
    }
    i++;
  }
  str[i] = 0;
  return str;
}

int inserirHighscore(FILE* f, char* anterior, char* nome, int nova_pontuacao){
  char novo[MAX_BUFFER], str[MAX_BUFFER];
  int i, pontuacao;
  truncate(nome, TAMANHO_NOME_MAXIMO);
  sprintf(novo, "%s %d\n", nome, nova_pontuacao);
  for(i = 0;fgets(str,MAX_BUFFER,f); i++){
    sscanf(str, "%*s %d", &pontuacao);
    if(nova_pontuacao > pontuacao){
      strcat(novo, str);
      break;
    }
    strcat(anterior,str);
  }
  strcat(anterior, novo);
  return i;
}

int atualizarHighscore(FILE* f, char* nome, int nova_pontuacao){
  char anterior[MAX_BUFFER], depois[MAX_BUFFER];
  int indice_novo_highscore = inserirHighscore(f, anterior, nome, nova_pontuacao);
  if(fread(depois, MAX_BUFFER, 1, f) > MAX_BUFFER){
    strcpy(depois, "");
  }
  fseek(f, 0, SEEK_SET);
  fprintf(f, "%s%s", anterior, depois);
  fclose(f);
  return indice_novo_highscore;
}

int novoHighscore(char* nome, int nova_pontuacao){
  FILE *f = fopen(HIGHSCORE_PATH,"r+");
  if(f){
    return atualizarHighscore(f, nome, nova_pontuacao);
  } else {
    return -1;
  }
}

char* nomeValido(char* nome){
  char* nomeDescoficado = urlDecode(nome);
  char* nomeFinal = HTMLentitles(nomeDescoficado);
  free(nomeDescoficado);
  return nomeFinal;
}

void imprimeHighscore(int i, int indice_novo_highscore, char* nome, int pontuacao){
  char* nomeSeguro = nomeValido(nome);
  if(i == indice_novo_highscore){
    printf("<tr style='background-color:yellow'><td>%s</td><td>%d</d></tr>\n", nomeSeguro, pontuacao);
  } else {
    printf("<tr><td>%s</td><td>%d</d></tr>\n", nomeSeguro, pontuacao);
  }
  free(nomeSeguro);
}

void imprimeHighscores(int indice_novo_highscore){
  FILE *f = fopen(HIGHSCORE_PATH,"r");
  int i, pontuacao;
  char str[MAX_BUFFER], nome[MAX_BUFFER];
  if(f){
    for(i = 0; fgets(str,MAX_BUFFER,f); i++) {
      sscanf(str,"%s %d", nome, &pontuacao);
      imprimeHighscore(i, indice_novo_highscore, nome, pontuacao);
    }
    fclose(f);
  }
}

char* obter_estado(int id){
	char fileName[15];
	sprintf(fileName,"data/%X",id);
	FILE* f = fopen(fileName,"r");
  char* mapa = 0;
  if(f){
	 mapa = malloc(MAX_BUFFER);
	 if(fgets(mapa,MAX_BUFFER,f) == 0){
     mapa = 0;
   }
	 fclose(f);
  }
	return mapa;
}

int buscar_id(){
  unsigned int id = 0;
	char* uid = getCookie("uid");
  if(uid){
	 sscanf(uid,"%X",&id);
   free(uid);
  }
	return id;
}

void imprime(int indice_novo_highscore){
  printf("<h1>HIGHSCORES</h1>\n");
  printf("<table border=1>\n");
  printf("<tr><th>Nome</th><th>Pontos</th></tr>\n");
  imprimeHighscores(indice_novo_highscore);
  printf("<tr><td></td><td><a href='/cgi-bin/jogo'><button>Nova partida</button></a></td></tr>\n");
  printf("</table>\n");
}

int main(){
  int id = buscar_id();
  int indice_novo_highscore = -1;
  int pontuacao;
  if(id){
    char* estado = obter_estado(id);
	   ESTADO e = str2estado(estado);
     if(e.infojog.vida <= 0){
       pontuacao = e.info.pontuacao;
       printf("Set-Cookie: uid=deleted; expires=Thu, 01 Jan 1970 00:00:00 GMT\n");
       char* nome = getenv("QUERY_STRING");
       if(nome[0]){
         indice_novo_highscore = novoHighscore(nome,pontuacao);
       }
     }
  }
  COMECAR_HTML;
  imprime(indice_novo_highscore);
  return 0;
}
